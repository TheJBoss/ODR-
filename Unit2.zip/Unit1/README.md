# ODR-

This is a website based off an idea a friend of mine had. We bounced ideas and generated many of the feautures 
together but the base idea was originally his.

We wanted an easier way to interact with other recreational hockey players. The main idea is to help others find 
Outdoor Rinks near by, but has expanded in to a full "social media platform" with the ability to add friends, create
teams and even sell or re-home unused gear. 

I am currently working on this project as part of my COMP266 course at Athabasca University but I have a real passion
to continue to work on this site for the forseeable future. I have purchased the domain www.odrplus.ca and I have 
github pages to host my content. Its fairly basic as of writing this due to the nature of the course but I have no
doubts it will become a fully functioning website with many users in no time.

Endgame Features:
Google maps with pins for Outdoor rinks
  -distance to
  -ice quality (player rated)
  -current players (if any)
Team creation;
Stat tracking;
Tournaments;
Full marketplace and Free section;
Fully customizable profile;
